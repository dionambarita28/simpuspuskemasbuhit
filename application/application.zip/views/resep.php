<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mx-auto">
                        <h4 class="header-title text-center text-uppercase">Resep Obat Rekam Medis</h4>
                        <?= validation_errors('<div class="alert alert-danger" role="alert">', '</div>'); ?>
                    <?= $this->session->flashdata('message'); ?>

                        <table class="table table-borderless mt-4 mb-3">
                          <tbody>
                            <tr>
                              <th scope="row">No Rekam Medis</td>
                              <td>:</td>
                              <td><?=$rekam_medis->no_rm;?></td>
                            </tr>
                            <tr>
                              <th scope="row">Nama Pasien</td>
                              <td>:</td>
                              <td><?=$rekam_medis->nama_pasien;?></td>
                            </tr>
                            <tr>
                              <th scope="row">Tgl Pemeriksaan</td>
                              <td>:</td>
                              <td><?=$pemeriksaan->tgl_pemeriksaan;?></td>
                            </tr>
                            <tr>
                              <th scope="row">Diagnosa</td>
                              <td>:</td>
                              <td><?=$pemeriksaan->diagnosa_penyakit;?></td>
                            </tr>
                          </tbody>
                        </table>
                            <form method="post" action="<?= base_url('pemeriksaan/addResep'); ?>" class="mb-4">
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="supplier" class="col-form-label">Nama Obat</label>
                                        <input class="form-control inp" type="text" value="" id="nama-obat-auto" name="nama_obat" placeholder="Ketikan Nama Obat....">
                                        <input type="hidden" value="" id="userid" name="id_obat">
                                        <input type="hidden" value="<?=$rekam_medis->no_rm;?>" id="no_rm" name="no_rm">
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="supplier" class="col-form-label">Jumlah</label>
                                        <input class="form-control inp" type="number" value="0" id="no_rm" name="jumlah">
                                    </div>
                                    <div class="form-group ml-auto col-12">
                                    <button type="submit" class="btn btn-success btn-md" name="submit"><i class="fa fa-paper-plane"></i> Tambah Resep</button>
                                    <button type="reset" class="btn btn-default btn-md">Reset</button>
                            
                                    </div>
                                </div>
                                
                            </form>
                        </div>
                    </div>

                    <div class="table-responsive">
                      <?= $this->session->flashdata('message2'); ?>
                        <table class="table" id="table-kategori">
                          <thead class="bg-default">
                            <tr>
                              <th scope="col">ID Obat</th>
                              <th scope="col">Nama Obat</th>
                              <th scope="col">Jumlah</th>
                              <th scope="col">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php foreach($resep_list as $resep_l) : ?>
                            <tr>
                              <th scope="row"><?= $resep_l->id_obat;?></th>
                              <td><?=$resep_l->nama_obat;?></td>
                              <td><?=$resep_l->jumlah;?></td>
                              <td><button class="btn btn-danger btn-xs btn-resep" data-toggle="modal" data-target="#hapus-resep" data-idresep="<?= $resep_l->id;?>">HAPUS</button></td>
                            </tr>
                            <?php endforeach ?>
                          </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>

<div class="modal fade" id="hapus-resep" tabindex="-1" role="dialog" aria-labelledby="hapus" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <h5 class="modal-title mb-5" id="hapus-title" align="center">Yakin Hapus data?</h5>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <a href="" class="btn btn-danger" id="h-all"><i class="fa fa-trash"></i> Hapus + Stok</a>
        <a href="" class="btn btn-warning" id="h-only"><i class="fa fa-eraser"></i> Hapus</a>
      </div>
    </div>
  </div>
</div>