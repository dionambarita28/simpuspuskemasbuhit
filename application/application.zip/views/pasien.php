<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-body row top-info">
                    <div class="col-md-6 clearfix">
                        <input type="text" id="searchbox" class="pull-left form-search col-8" placeholder="Pencarian.." value=""> 
                    </div>
                    <div class="clearfix col-md-6">
                        <div class="pull-right">
                            <a href="<?= base_url('pasien/addPasien'); ?>" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Pasien</a>
                            <a href="" class="btn btn-light"><i class="fa fa-file-text"></i> Laporan Pasien</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <?= $this->session->flashdata('message'); ?>
                    <div class="data-tables table-responsive" id="anti-search">
                    		<table id="table-obat" class="table table-striped table-hover" style="width:100%">
                            <thead class="bg-secondary">
                                <tr class="text-uppercase text-sm text-white">
                                    <th scope="col" class="text-center">No Pasien</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Kelamin</th>
                                    <th scope="col">Tgl Lahir</th>
                                    <th scope="col">Tinggi</th>
                                    <th scope="col">Berat</th>
                                    <th scope="col" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php foreach($pasien_list as $pasien) : ?>
                                    <tr>
                                      <td scope="row" class="text-center"><strong><?= $pasien['no_pasien']; ?></strong></td>
                                      <td><?= $pasien['nama']; ?></td>
                                      <td><?= $pasien['kelamin']; ?></td>
                                      <td><?= $pasien['tgl_lahir']; ?></td>
                                      <td><?= $pasien['tinggi']; ?> cm</td>
                                      <td><?= $pasien['berat']; ?> kg</td>
                                        <td class="text-center">
                                            <a href="" class="btn btn-success btn-xs"><i class="fa fa-pencil"></i></a>
                                            <button class="btn btn-danger btn-xs" data-target="#hapus" data-toggle="modal"><i class="fa fa-trash"></i></button>
                                            <a href="<?= base_url('pasien/daftar/').$pasien['no_pasien'];?>" class="btn btn-warning btn-xs">Daftar</a>
                                        </td>
                                    </tr>
                                    <?php endforeach ?>

                            </tbody>

                        </table>



                    </div>
                </div>
            </div>
        </div>
        <!-- data table end -->
    </div>
</div>

<div class="modal fade" id="hapus" tabindex="-1" role="dialog" aria-labelledby="hapus" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <h5 class="modal-title mb-5" id="hapus-title" align="center">Yakin Hapus data?</h5>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="button" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</button>
      </div>
    </div>
  </div>
</div>