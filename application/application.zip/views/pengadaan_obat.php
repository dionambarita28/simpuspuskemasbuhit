<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mx-auto">
                        <h4 class="header-title text-center text-uppercase">Pengadaan Obat</h4>
                        <?= validation_errors('<div class="alert alert-danger" role="alert">', '</div>'); ?>
                        <?= $this->session->flashdata('message'); ?>

                            <form method="post" action="<?= base_url('pengadaan_obat/add'); ?>">
                                <div class="form-group">
                                    <label for="supplier" class="col-form-label">Supplier(asal)</label>
                                    <input class="form-control inp" type="text" value="" id="supplier" name="supplier" placeholder="Masukan nama supplier">
                                </div>
                                <div class="form-group">
                                    <label for="nama-obat" class="col-form-label">Nama Obat</label>
                                    <input class="form-control inp" type="text" value="" id="nama-obat-auto" name="nama_obat" placeholder="Ketikan Nama Obat....">
                                    <input type="hidden" value="" id="userid" name="obatid">
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <label for="nama-obat" class="col-form-label">Jumlah/<span id="obat_satuan"></span></label>
                                        <input class="form-control inp" type="number" value="" id="qty-obat" name="qty_obat" placeholder="0">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="nama-obat" class="col-form-label">Harga</label>
                                        <input class="form-control inp" type="text" value="" id="harga" name="harga" placeholder="0000">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="expired-obat" class="col-form-label">Expired</label>
                                        <input class="form-control inp" type="text" value="" id="expired" name="expired" placeholder="dd/mm/yyyy">
                                    </div>
                                </div>
                                
                                <div class="form-group mt-4" align="right">
                                    
                                    <button type="reset" class="btn btn-default btn-md mr-2">Reset</button>
                                    <button type="submit" class="btn btn-success btn-md"><i class="fa fa-paper-plane"></i> Submit</button>
                            
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>