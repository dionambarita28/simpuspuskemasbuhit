<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

	public $user;

	function __construct(){
		parent::__construct();
		$this->load->library('cetak_pdf');
		$this->load->model('Puskesmas','puskes');
	}

	function index()
	{	
		$pdf = new FPDF('P', 'mm','A4');

        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(20,7,"",0,0,'R');
        $pdf->Cell(0,7,'Laporan Pendaftaran',0,1,'C');
        $pdf->Cell(10,7,'',0,1);

        $pdf->SetFont('Arial','B',10);

        $pdf->Cell(8,7,'No',1,0,'C');
        $pdf->Cell(35,7,'No Pasien',1,0,'C');
        $pdf->Cell(80,7,'Nama Pasien',1,0,'C');
        $pdf->Cell(25,7,'Tgl Daftar',1,0,'C');
        $pdf->Cell(0,7,'Jenis Pasien',1,1,'C');

        $pdf->SetFont('Arial','',10);
        $pendaftaran = $this->db->get('pendaftaran')->result();
        $no=1;
        foreach ($pendaftaran as $data){
            $pdf->Cell(8,7,$no,1,0,'C');
            $pdf->Cell(35,7,$data->no_pasien,1,0);
            $pdf->Cell(80,7,$data->nama_pasien,1,0);
            $pdf->Cell(25,7,$data->tgl_berobat,1,0);
            $pdf->Cell(0,7,$data->jenis_pasien,1,1);
            $no++;
        }
        $pdf->Output();
	}
	function pasien()
	{	
		$pdf = new FPDF('P', 'mm','A4');

        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(20,7,"",0,0,'R');
        $pdf->Cell(0,7,'Laporan Pasien',0,1,'C');
        $pdf->Cell(10,7,'',0,1);

        $pdf->SetFont('Arial','B',10);

        $pdf->Cell(8,7,'No',1,0,'C');
        $pdf->Cell(35,7,'No Pasien',1,0,'C');
        $pdf->Cell(80,7,'Nama Pasien',1,0,'C');
        $pdf->Cell(25,7,'Tgl Daftar',1,0,'C');
        $pdf->Cell(0,7,'Jenis Pasien',1,1,'C');

        $pdf->SetFont('Arial','',10);
        $pendaftaran = $this->db->get('pendaftaran')->result();
        $no=1;
        foreach ($pendaftaran as $data){
            $pdf->Cell(8,7,$no,1,0,'C');
            $pdf->Cell(35,7,$data->no_pasien,1,0);
            $pdf->Cell(80,7,$data->nama_pasien,1,0);
            $pdf->Cell(25,7,$data->tgl_berobat,1,0);
            $pdf->Cell(0,7,$data->jenis_pasien,1,1);
            $no++;
        }
        $pdf->Output();
	}
}
